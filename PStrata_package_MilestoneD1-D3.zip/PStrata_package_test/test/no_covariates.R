N <- 1000
p <- 0.7
G <- rbinom(N, 1, p)
Z <- rbinom(N, 1, 0.5)
D <- G * Z
Y <- ifelse(G, rnorm(N, 7 + Z, 0.5), rnorm(N, 5, 1))

df <- data.frame(Z = Z, D = D, Y = Y)

res_no_covariates <- PS(S.formula = Z + D ~ 1,
                        Y.formula = Y ~ 1,
                        Y.family = gaussian(),
                        data = df,
                        monotonicity = "strong",
                        ER = c("00"),
                        chain = 1, iter = 500, warmup = 200)
res_no_covariates
