N <- 1000
G <- ifelse(runif(N) < 0.2, 0, ifelse(runif(N) < 0.5, 1, 3))
Z <- rbinom(N, 1, 0.5)
D <- (Z == 0) * (G >= 2) + (Z == 1) * (G %% 2)
X <- rnorm(N)
Y <- ifelse(G == 0, rnorm(N, 1.5 + 0.5 * X, 1),
            ifelse(G == 1, rnorm(N, 3 - X - 0.75*Z, 0.5),
                   rnorm(N, 2 + 3 * X, 2)))

df <- data.frame(Z = Z, D = D, Y = Y, X = X)

res_single_covariate_Y <- PS(S.formula = Z + D ~ 1,
                             Y.formula = Y ~ X + 1,
                             Y.family = gaussian(),
                             data = df,
                             monotonicity = "default",
                             ER = c("00", "11"),
                             chain = 1, iter = 500, warmup = 200)
res_single_covariate_Y
