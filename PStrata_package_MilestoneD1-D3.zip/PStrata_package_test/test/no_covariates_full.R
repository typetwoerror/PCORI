N <- 500
G <- ifelse(runif(N) < 0.3, 0, ifelse(runif(N) < 0.6, 3, 4))
Z <- rbinom(N, 1, 0.5)
D <- (Z == 0) * (G >= 2) + (Z == 1) * (G %% 2)
Y <- ifelse(G == 0, rnorm(N, 5, 1),
            ifelse(G == 1, rnorm(N, 7 + Z, 0.5),
                          rnorm(N, -3, 1)))

df <- data.frame(Z = Z, D = D, Y = Y)

res_no_covariate_full <- PS(S.formula = Z + D ~ 1,
                             Y.formula = Y ~ 1,
                             Y.family = gaussian(),
                             data = df,
                             monotonicity = "none",
                             ER = c("00", "11"),
                             chain = 1, iter = 500, warmup = 200)
res_no_covariate_full
