df <- read.csv('test/jobs/jobs.cvs')

res_employ_w_cov_00 <- PS(
  S.formula = Z + D ~ depress0 + age + sex + race + educ,
  Y.formula = employ6 ~ depress0 + age + sex + race + educ,
  Y.family = binomial(),
  data = df,
  monotonicity = "strong",
  ER = "00",
  chain = 1, warmup = 200, iter = 500
)

res_employ_w_cov <- PS(
  S.formula = Z + D ~ depress0 + age + sex + race + educ,
  Y.formula = employ6 ~ depress0 + age + sex + race + educ,
  Y.family = binomial(),
  data = df,
  monotonicity = "strong",
  ER = c(),
  chain = 1, warmup = 200, iter = 500
)

res_employ_wo_cov_00 <- PS(
  S.formula = Z + D ~ 1,
  Y.formula = employ6 ~ 1,
  Y.family = binomial(),
  data = df,
  monotonicity = "strong",
  ER = "00",
  chain = 1, warmup = 200, iter = 500
)

res_employ_wo_cov <- PS(
  S.formula = Z + D ~ 1,
  Y.formula = employ6 ~ 1,
  Y.family = binomial(),
  data = df,
  monotonicity = "strong",
  ER = c(),
  chain = 1, warmup = 200, iter = 500
)

res_depress_w_cov_00 <- PS(
  S.formula = Z + D ~ depress0 + age + sex + race + educ,
  Y.formula = depress6 ~ depress0 + age + sex + race + educ,
  Y.family = gaussian(),
  data = df,
  monotonicity = "strong",
  ER = "00",
  chain = 1, warmup = 200, iter = 500
)

res_depress_w_cov <- PS(
  S.formula = Z + D ~ depress0 + age + sex + race + educ,
  Y.formula = depress6 ~ depress0 + age + sex + race + educ,
  Y.family = gaussian(),
  data = df,
  monotonicity = "strong",
  ER = c(),
  chain = 1, warmup = 200, iter = 500
)

res_depress_wo_cov <- PS(
  S.formula = Z + D ~ 1,
  Y.formula = depress6 ~ 1,
  Y.family = gaussian(),
  data = df,
  monotonicity = "strong",
  ER = c(),
  chain = 1, warmup = 200, iter = 500
)

