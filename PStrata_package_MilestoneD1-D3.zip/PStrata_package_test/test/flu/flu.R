df <- read.table("test/flu/flu-clean.txt", header = T, sep = ' ')

df$age <- as.numeric(df$age)
df$age[is.na(df$age)] <- mean(df$age, na.rm = T)

res_flu_00_11 <- PS(
  S.formula = grp + fluy2 ~ age + copd,
  Y.formula = wcxho79 ~ age + copd,
  Y.family = binomial(),
  data = df,
  monotonicity = "none",
  ER = c("00", "11"),
  chains = 1, warmup = 200, iter = 500
)

res_flu_00_11_oneway <- PS(
  S.formula = grp + fluy2 ~ age + copd,
  Y.formula = wcxho79 ~ age + copd,
  Y.family = binomial(),
  data = df,
  monotonicity = "default",
  ER = c("00", "11"),
  chains = 1, warmup = 200, iter = 500
)

