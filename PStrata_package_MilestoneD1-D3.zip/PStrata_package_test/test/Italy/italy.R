df <- read.csv('test/Italy/italy.csv')

res_italy_A <- PS(
  S.formula = Z + A ~ rv0,
  Y.formula = outcome ~ rv0,
  Y.family = binomial("logit"),
  data = dplyr::sample_n(df, 1000),
  monotonicity = "default",
  ER = c(),
  chains = 1, warmup = 200, iter = 500
)

res_italy_D <- PS(
  S.formula = Z + D ~ rv0,
  Y.formula = outcome ~ rv0,
  Y.family = binomial("logit"),
  data = dplyr::sample_n(df, 1000),
  monotonicity = "default",
  ER = c(),
  chains = 1, warmup = 200, iter = 500
)
