########################################################################
# The following code reproduces Table 1 to 3 (tables for scenario 1) 

# ape: average point estimates of the existing approaches
# mcse: Monte Carlo standard error of the existing approaches
# cp\_a: coverage probability of each estimator regarding tau_a

########################################################################

source(".../sim_scenario1.R")# need to change the directory here
require(geepack)
require(xtable)

######
#I=10
######

simscenario1(seed=0623,n=10,m1=50,m2=50,rho=0.01,corstr="independence")
# ape & 6.369 & 6.071 & 6.071 & 6.046 \\ 
# mcse & 1.130 & 1.093 & 1.093 & 1.095 \\ 
# cp\_a & 0.936 & 0.835 & 0.835 & 0.832 \\ 
# cp\_c & 0.137 & 0.069 & 0.069 & 0.070 \\ 
# cp\_itt & 0.216 & 0.132 & 0.132 & 0.128 \\ 

simscenario1(seed=0623,n=10,m1=50,m2=50,rho=0.05,corstr="independence")
# ape & 6.319 & 6.041 & 6.041 & 6.018 \\ 
# mcse & 1.161 & 1.100 & 1.100 & 1.101 \\ 
# cp\_a & 0.920 & 0.822 & 0.822 & 0.815 \\ 
# cp\_c & 0.145 & 0.069 & 0.069 & 0.071 \\ 
# cp\_itt & 0.226 & 0.110 & 0.110 & 0.111 \\ 

simscenario1(seed=0623,n=10,m1=50,m2=50,rho=0.1,corstr="independence")
# ape & 6.417 & 6.123 & 6.123 & 6.100 \\ 
# mcse & 1.166 & 1.117 & 1.117 & 1.120 \\ 
# cp\_a & 0.920 & 0.829 & 0.829 & 0.815 \\ 
# cp\_c & 0.138 & 0.070 & 0.070 & 0.069 \\ 
# cp\_itt & 0.203 & 0.124 & 0.124 & 0.127 \\ 

simscenario1(seed=0623,n=10,m1=20,m2=80,rho=0.01,corstr="independence")
# ape & 6.440 & 5.937 & 5.937 & 5.895 \\ 
# mcse & 1.319 & 1.135 & 1.135 & 1.140 \\ 
# cp\_a & 0.916 & 0.859 & 0.859 & 0.848 \\ 
# cp\_c & 0.207 & 0.130 & 0.130 & 0.131 \\ 
# cp\_itt & 0.295 & 0.196 & 0.196 & 0.200 \\ 

simscenario1(seed=0623,n=10,m1=20,m2=80,rho=0.05,corstr="independence")
# ape & 6.298 & 5.844 & 5.844 & 5.804 \\ 
# mcse & 1.358 & 1.163 & 1.163 & 1.164 \\ 
# cp\_a & 0.899 & 0.826 & 0.826 & 0.817 \\ 
# cp\_c & 0.231 & 0.141 & 0.141 & 0.145 \\ 
# cp\_itt & 0.307 & 0.221 & 0.221 & 0.233 \\ 

simscenario1(seed=0623,n=10,m1=20,m2=80,rho=0.1,corstr="independence")
# ape & 6.372 & 5.903 & 5.903 & 5.863 \\ 
# mcse & 1.315 & 1.119 & 1.119 & 1.120 \\ 
# cp\_a & 0.918 & 0.855 & 0.855 & 0.839 \\ 
# cp\_c & 0.217 & 0.140 & 0.140 & 0.143 \\ 
# cp\_itt & 0.305 & 0.211 & 0.211 & 0.218 \\ 

######
#I=30
######

simscenario1(seed=0623,n=30,m1=50,m2=50,rho=0.01,corstr="independence")

# \begin{table}[ht]
# \centering
# \begin{tabular}{rrrrr}
# \hline
# & ITT-pre & ITT-all & ATreated & Reg \\ 
# \hline
# ape & 6.379 & 6.089 & 6.089 & 6.067 \\ 
# mcse & 0.661 & 0.638 & 0.638 & 0.637 \\ 
# cp\_a & 0.936 & 0.813 & 0.813 & 0.814 \\ 
# cp\_c & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# \hline
# \end{tabular}
# \end{table}

simscenario1(seed=0623,n=30,m1=50,m2=50,rho=0.05,corstr="independence")

# \begin{table}[ht]
# \centering
# \begin{tabular}{rrrrr}
# \hline
# & ITT-pre & ITT-all & ATreated & Reg \\ 
# \hline
# ape & 6.373 & 6.077 & 6.077 & 6.054 \\ 
# mcse & 0.677 & 0.654 & 0.654 & 0.654 \\ 
# cp\_a & 0.939 & 0.795 & 0.795 & 0.782 \\ 
# cp\_c & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# \hline
# \end{tabular}
# \end{table}

simscenario1(seed=0623,n=30,m1=50,m2=50,rho=0.1,corstr="independence")

# \begin{table}[ht]
# \centering
# \begin{tabular}{rrrrr}
# \hline
# & ITT-pre & ITT-all & ATreated & Reg \\ 
# \hline
# ape & 6.377 & 6.083 & 6.083 & 6.061 \\ 
# mcse & 0.660 & 0.630 & 0.630 & 0.629 \\ 
# cp\_a & 0.941 & 0.804 & 0.804 & 0.800 \\ 
# cp\_c & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.001 & 0.000 & 0.000 & 0.000 \\ 
# \hline
# \end{tabular}
# \end{table}

simscenario1(seed=0623,n=30,m1=20,m2=80,rho=0.01,corstr="independence")
# \begin{table}[ht]
# \centering
# \begin{tabular}{rrrrr}
# \hline
# & ITT-pre & ITT-all & ATreated & Reg \\ 
# \hline
# ape & 6.334 & 5.867 & 5.867 & 5.826 \\ 
# mcse & 0.717 & 0.639 & 0.639 & 0.641 \\ 
# cp\_a & 0.944 & 0.791 & 0.791 & 0.778 \\ 
# cp\_c & 0.002 & 0.002 & 0.002 & 0.002 \\ 
# cp\_itt & 0.008 & 0.002 & 0.002 & 0.002 \\ 
# \hline
# \end{tabular}
# \end{table}


simscenario1(seed=0623,n=30,m1=20,m2=80,rho=0.05,corstr="independence")
# \begin{table}[ht]
# \centering
# \begin{tabular}{rrrrr}
# \hline
# & ITT-pre & ITT-all & ATreated & Reg \\ 
# \hline
# ape & 6.343 & 5.875 & 5.875 & 5.834 \\ 
# mcse & 0.713 & 0.627 & 0.627 & 0.626 \\ 
# cp\_a & 0.946 & 0.802 & 0.802 & 0.780 \\ 
# cp\_c & 0.002 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.006 & 0.004 & 0.004 & 0.005 \\ 
# \hline
# \end{tabular}
# \end{table}

simscenario1(seed=0623,n=30,m1=20,m2=80,rho=0.1,corstr="independence")
# \begin{table}[ht]
# \centering
# \begin{tabular}{rrrrr}
# \hline
# & ITT-pre & ITT-all & ATreated & Reg \\ 
# \hline
# ape & 6.352 & 5.878 & 5.878 & 5.837 \\ 
# mcse & 0.737 & 0.643 & 0.643 & 0.642 \\ 
# cp\_a & 0.945 & 0.801 & 0.801 & 0.781 \\ 
# cp\_c & 0.002 & 0.001 & 0.001 & 0.001 \\ 
# cp\_itt & 0.016 & 0.003 & 0.003 & 0.004 \\ 
# \hline
# \end{tabular}
# \end{table}

######
#I=60
######

simscenario1(seed=0623,n=60,m1=50,m2=50,rho=0.01,corstr="independence")
# \begin{table}[ht]
# \centering
# \begin{tabular}{rrrrr}
# \hline
# & ITT-pre & ITT-all & ATreated & Reg \\ 
# \hline
# ape & 6.362 & 6.067 & 6.067 & 6.045 \\ 
# mcse & 0.479 & 0.459 & 0.459 & 0.458 \\ 
# cp\_a & 0.939 & 0.777 & 0.777 & 0.766 \\ 
# cp\_c & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# \hline
# \end{tabular}
# \end{table}

simscenario1(seed=0623,n=60,m1=50,m2=50,rho=0.05,corstr="independence")
# ape & 6.366 & 6.070 & 6.070 & 6.047 \\ 
# mcse & 0.467 & 0.441 & 0.441 & 0.440 \\ 
# cp\_a & 0.949 & 0.776 & 0.776 & 0.763 \\ 
# cp\_c & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.000 & 0.000 & 0.000 & 0.000 \\ 

simscenario1(seed=0623,n=60,m1=50,m2=50,rho=0.1,corstr="independence")
# ape & 6.341 & 6.045 & 6.045 & 6.022 \\ 
# mcse & 0.470 & 0.446 & 0.446 & 0.445 \\ 
# cp\_a & 0.948 & 0.752 & 0.752 & 0.740 \\ 
# cp\_c & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.000 & 0.000 & 0.000 & 0.000 \\ 

simscenario1(seed=0623,n=60,m1=20,m2=80,rho=0.01,corstr="independence")
# ape & 6.358 & 5.893 & 5.893 & 5.852 \\ 
# mcse & 0.519 & 0.446 & 0.446 & 0.446 \\ 
# cp\_a & 0.950 & 0.742 & 0.742 & 0.705 \\ 
# cp\_c & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.000 & 0.000 & 0.000 & 0.000 \\ 

simscenario1(seed=0623,n=60,m1=20,m2=80,rho=0.05,corstr="independence")
# ape & 6.362 & 5.885 & 5.885 & 5.844 \\ 
# mcse & 0.513 & 0.432 & 0.432 & 0.432 \\ 
# cp\_a & 0.956 & 0.736 & 0.736 & 0.700 \\ 
# cp\_c & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.000 & 0.000 & 0.000 & 0.000 \\ 

simscenario1(seed=0623,n=60,m1=20,m2=80,rho=0.1,corstr="independence")
# ape & 6.357 & 5.885 & 5.885 & 5.843 \\ 
# mcse & 0.532 & 0.452 & 0.452 & 0.455 \\ 
# cp\_a & 0.941 & 0.720 & 0.720 & 0.690 \\ 
# cp\_c & 0.000 & 0.000 & 0.000 & 0.000 \\ 
# cp\_itt & 0.000 & 0.000 & 0.000 & 0.000 \\ 

