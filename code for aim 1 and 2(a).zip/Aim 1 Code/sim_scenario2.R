#####################################################
# A function to reproduce the results for scenario 2  
#####################################################

source(".../functions.R")# need to change the directory here
require(geepack)
require(xtable)

simscenario2=function(seed,n,m1,m2,rho,corstr){
  require(xtable)
  # clustering structure 
  # n=30
  # m1=50
  # m2=50
  m=m1+m2
  cluster=rep(1:n,each=m)
  subject=rep(1:m,n)
  time=rep(rep(c(0,1),c(m1,m2)),n)
  
  # save results
  nsim=1000
  EST=LCL=UCL=matrix(NA,nsim,4)
  colnames(EST)=colnames(LCL)=colnames(UCL)=
    c("ITT-pre","ITT-all","ATreated","Reg")
  TAU_a=TAU_c=TAU_itt=rep(NA,nsim)
  
  # load functions
  source("D:/B1 Grant Application/2019 Duke PCORI Selection Bias OUD/R/ProgressReport/functions.R")
  for(i in 1:nsim){
    Z=rep(0,n)
    Z[sample(1:n,n/2)]=1
    Z=rep(Z,each=m)
    
    # residual error and clustering effect
    sigma=5
    e=rnorm(n*m,0,sigma)
    # rho=0.1
    gamma=rep(rnorm(n,0,sigma*sqrt(rho/(1-rho))),each=m)
    
    # create dataset
    data=data.frame(cluster=cluster, subject=subject, 
                    time=time, Z=Z, gamma=gamma, e=e)
    data0=data[data$time==0,]     # pre-randomization
    data1=data[data$time==1,]     # post-randomization
    
    # model parameters
    beta_n=-0.6
    beta_c=0
    rho=0.1
    
    # population size
    N=20000        
    x1=rnorm(N)
    x2=rbinom(N,1,0.5)
    
    # simulate principal strata membership
    xb_c=c(beta_c+0.5*x1+0.6*x2)
    xb_n=c(beta_n-1*x1+0.3*x2)
    p_a=1/(1+exp(xb_c)+exp(xb_n))
    p_c=exp(xb_c)/(1+exp(xb_c)+exp(xb_n))
    p_n=exp(xb_n)/(1+exp(xb_c)+exp(xb_n))
    
    # proportion of strata
    (pi_a=mean(p_a))
    (pi_c=mean(p_c))
    (pi_n=mean(p_n))
    
    # simulate membership
    S=matrix(NA,N,3)
    colnames(S)=c("a","c","n")
    for(k in 1:N){
      S[k,]=rmultinom(1,1,prob=c(p_a[k],p_c[k],p_n[k]))
    }
    
    # simulate potential outcomes
    mu_a_0=-1+0.4*x1-0.6*x2
    mu_a_1=5+1.2*x1+0.2*x2
    mu_c_0=1+0.6*x1+0.4*x2
    mu_c_1=4-0.2*x1+0.4*x2
    mu_n_0=mu_n_1=-2+0.2*x1+0.1*x2
    
    # data frame
    pdata=data.frame(x1=x1,x2=x2,p_a=p_a,p_c=p_c,p_n=p_n,S=S,
                     mu_a_0=mu_a_0,mu_a_1=mu_a_1,mu_c_0=mu_c_0,
                     mu_c_1=mu_c_1,mu_n_0=mu_n_0,mu_n_1=mu_n_1)
    
    # true causal estimands
    tau_a=mean((mu_a_1-mu_a_0)*p_a)/pi_a
    tau_c=mean((mu_c_1-mu_c_0)*p_c)/pi_c
    tau_itt=pi_a*tau_a+pi_c*tau_c
    
    TAU_a[i]=tau_a
    TAU_c[i]=tau_c
    TAU_itt[i]=tau_itt
    
    # simulate cohort pre-randomization
    pdata0=pdata[pdata$S.a==1,][1:nrow(data0),]
    last=tail(sort(as.numeric(rownames(pdata0))),n=1)
    data0=cbind(data0,pdata0)
    
    # simulate the recruited post randomization among intervention clusters
    pdata1=pdata[-(1:last),]
    pdata1_trt=pdata1[(pdata1$S.a==1)|(pdata1$S.c==1),][1:((n/2)*m2),]
    last1=tail(sort(as.numeric(rownames(pdata1_trt))),n=1)
    
    # simulate the recruited post randomization among control clusters
    pdata2=pdata[-(1:last1),]
    pdata2_ctr=pdata2[pdata2$S.a==1,][1:((n/2)*m2),]
    last2=tail(sort(as.numeric(rownames(pdata2_ctr))),n=1)
    
    # create data and combine
    data2=rbind(
      cbind(data1[data1$Z==1,],pdata1_trt),
      cbind(data1[data1$Z==0,],pdata2_ctr))
    analdata=rbind(data0,data2)
    
    # simulate actual treatment 
    analdata$W=NA
    analdata$W[analdata$Z==1&analdata$S.a==1]=rbinom(sum(analdata$Z==1&analdata$S.a==1),1,0.8)
    analdata$W[analdata$Z==1&analdata$S.c==1]=rbinom(sum(analdata$Z==1&analdata$S.c==1),1,0.6)
    # analdata$W[analdata$Z==1&analdata$S.n==1]=0
    analdata$W[analdata$Z==0&analdata$S.a==1]=rbinom(sum(analdata$Z==0&analdata$S.a==1),1,0.2)
    # analdata$W[analdata$Z==0&analdata$S.c==1]=0
    # analdata$W[analdata$Z==0&analdata$S.n==1]=0
    
    # simulate observed outcomes
    analdata$y=NA
    
    analdata$y[analdata$S.a==1&analdata$W==1]=
      (analdata$mu_a_1+analdata$gamma+analdata$e)[analdata$S.a==1&analdata$W==1]
    analdata$y[analdata$S.c==1&analdata$W==1]=
      (analdata$mu_c_1+analdata$gamma+analdata$e)[analdata$S.c==1&analdata$W==1]
    
    analdata$y[analdata$S.a==1&analdata$W==0]=
      (analdata$mu_a_0+analdata$gamma+analdata$e)[analdata$S.a==1&analdata$W==0]
    # analdata$y[analdata$S.c==1&analdata$W==0]=
    #   (analdata$mu_c_0+analdata$gamma+analdata$e)[analdata$S.c==1&analdata$W==0]
    
    # save results
    res1=itt1(data=analdata,corstr)
    res2=itt2(data=analdata,corstr)
    res3=astreated(data=analdata,corstr)
    res4=regression(data=analdata,corstr)
    EST[i,]=c(res1$beta,res2$beta,res3$beta,res4$beta)
    LCL[i,]=c(res1$lcl,res2$lcl,res3$lcl,res4$lcl)
    UCL[i,]=c(res1$ucl,res2$ucl,res3$ucl,res4$ucl)
    
    # loop control
    if(i%%500==0) print(i)
  }
  
  # results
  ape=colMeans(EST)
  mcse=apply(EST,2,sd)
  cp_a=colMeans(matrix(mean(TAU_a),nrow(EST),ncol(EST))<=UCL & 
                  matrix(mean(TAU_a),nrow(EST),ncol(EST))>=LCL)
  cp_c=colMeans(matrix(mean(TAU_c),nrow(EST),ncol(EST))<=UCL & 
                  matrix(mean(TAU_c),nrow(EST),ncol(EST))>=LCL)
  cp_itt=colMeans(matrix(mean(TAU_itt),nrow(EST),ncol(EST))<=UCL & 
                    matrix(mean(TAU_itt),nrow(EST),ncol(EST))>=LCL)
  restable=rbind(ape,mcse,cp_a,cp_c,cp_itt)
  xtable(restable,digits=3)
}

