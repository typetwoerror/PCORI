########################################################
# functions for implementing existing analytical models
########################################################
require(geepack)

itt1=function(data,corstr){
  # pre-randomized diagnosed
  subdata=subset(data,time==0,drop=T)
  model=geeglm(y~Z,id=cluster,data=subdata,family=gaussian,corstr=corstr)
  fit=summary(model)
  beta=as.numeric(coef(model))[2]
  se=coef(fit)[2,2]
  I=length(unique(data$cluster))
  lcl=beta-qt(0.975,df=I-2)*se
  ucl=beta+qt(0.975,df=I-2)*se
  return(list(beta=beta,lcl=lcl,ucl=ucl))
}

itt2=function(data,corstr){
  # whole sample
  model=geeglm(y~Z,id=cluster,data=data,family=gaussian,corstr=corstr)
  fit=summary(model)
  beta=as.numeric(coef(model))[2]
  se=coef(fit)[2,2]
  I=length(unique(data$cluster))
  lcl=beta-qt(0.975,df=I-2)*se
  ucl=beta+qt(0.975,df=I-2)*se
  return(list(beta=beta,lcl=lcl,ucl=ucl))
}

astreated=function(data,corstr){
  # as treated analysis
  model=geeglm(y~W,id=cluster,data=data,family=gaussian,corstr=corstr)
  fit=summary(model)
  beta=as.numeric(coef(model))[2]
  se=coef(fit)[2,2]
  I=length(unique(data$cluster))
  lcl=beta-qt(0.975,df=I-2)*se
  ucl=beta+qt(0.975,df=I-2)*se
  return(list(beta=beta,lcl=lcl,ucl=ucl))
}

regression=function(data,corstr){
  # regression adjustment
  model=geeglm(y~Z+time+x1+x2+time*x1+time*x2,id=cluster,data=data,family=gaussian,corstr=corstr)
  fit=summary(model)
  beta=as.numeric(coef(model))[2]
  se=coef(fit)[2,2]
  I=length(unique(data$cluster))
  lcl=beta-qt(0.975,df=I-2)*se
  ucl=beta+qt(0.975,df=I-2)*se
  return(list(beta=beta,lcl=lcl,ucl=ucl))
}