The current folder includes R code for reproducing Table 1 to 6 in the PCORI progress report for "Aim 1".
For questions or comments about the code please contact Fan Li at <fan.f.li@yale.edu>.

I. List of Supporting Files: Some of these supporting files are sourced in the main files that reproduce the tables.

1) functions.r = four functions to implement "itt1", "itt2", "astreated", and "regression" methods;
2) sim_scenario1.r = function to reproduce the selective metrics under scenario 1 and independence working correlation structure;
3) sim_scenario2.r = function to reproduce the selective metrics under scenario 2 and independence working correlation structure.

II. List of Main Files: These main files are used to reproduce the results in Table 1 to 6.

4) res_scenario1_Table1to3.r = reproduce simulation results in Table 1 to Table 3;
5) res_scenario1_Table4to6.r = reproduce simulation results in Table 4 to Table 6.

III. Software 

Analyses were conducted with R, version 3.6.3 (https://www.r-project.org/).
The calculations used R packages geepack (version 1.2-1), xtable (version 1.8-4).

IV. R commands for the installation of R packages 

install.packages(c("geepack", "xtable")) 