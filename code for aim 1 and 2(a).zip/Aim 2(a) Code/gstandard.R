###############################################################################
# A function to simulate the true CACE and PCE for a fixed-featured population
###############################################################################

gstandard <- function(ICC){
  
  set.seed(1112)
  
  n <- 200
  m <- 200
  cluster <- rep(1:n, each=m)
  subject <- rep(1:m, n)
  
  nsims <- 100
  
  tau_pop <- rep(0, nsims)
  tau.a_pop <- rep(0, nsims)
  tau.c_pop <- rep(0, nsims)
  
  for (i in 1:nsims){
    mu1 <- rnorm(n,0,1)
    mu2 <- rnorm(n,0,1)
    #Generate two individual covariates with cluster-specific population mean
    X1 <- rnorm(n*m, rep(mu1, each=m), 1)
    X2 <- rnorm(n*m, rep(mu2, each=m), 1)
    
    #Use the well-tuned mechanism parameters from the population simulation
    vector_a <- c(0, 0, 0) #for identifiability
    vector_c <- c(0.3, 0.2, 0.1)
    vector_n <- c(-0.3, 0.1, 0.2)
    
    num_a <- exp(vector_a[1]+vector_a[2]*X1+vector_a[3]*X2)
    num_c <- exp(vector_c[1]+vector_c[2]*X1+vector_c[3]*X2)
    num_n <- exp(vector_n[1]+vector_n[2]*X1+vector_n[3]*X2)
    denom <- num_a + num_c + num_n
    
    pa_vector <- num_a/denom
    pc_vector <- num_c/denom
    pn_vector <- num_n/denom
    
    membership.matrix <- NULL
    for (j in 1:m*n){
      membership.matrix <- cbind(membership.matrix, as.vector(rmultinom(1,1,c(pa_vector[j], pc_vector[j], pn_vector[j]))))
    }
    a_membership <- membership.matrix[1,]
    c_membership <- membership.matrix[2,]
    n_membership <- membership.matrix[3,]
    
    #ICC=sigma2_gamma/sigma2_y, assume total sigma2_y=1
    rho <- ICC
    #Cluster-level random effect
    gamma <- rep(rnorm(n, 0, sqrt(rho)), each=m)
    
    #Generate means and the potential outcomes
    mu_a_0 <- gamma+0.3*X1+0.5*X2
    mu_a_1 <- gamma+0.6*X1+0.2*X2+3
    mu_c_0 <- gamma+0.4*X1+0.4*X2+1
    mu_c_1 <- gamma+0.8*X1+0.3*X2+3
    mu_n_0 <- mu_n_1 <- gamma+0.3*X1+0.4*X2-1
    
    #sigma2_epsilon=1-ICC
    Y_a_0 <- rnorm(n*m, mu_a_0, sqrt(1-rho))
    Y_a_1 <- rnorm(n*m, mu_a_1, sqrt(1-rho))
    Y_c_0 <- rnorm(n*m, mu_c_0, sqrt(1-rho))
    Y_c_1 <- rnorm(n*m, mu_c_1, sqrt(1-rho))
    Y_n_1 <- Y_n_0 <- rnorm(n*m, mu_n_0, sqrt(1-rho))
    
    #Iteration-specific CACE, tau_a, tau_c, use their mean to get truth
    tau_pop[i] <- mean(c((Y_a_1-Y_a_0)[a_membership==1], (Y_c_1-Y_c_0)[c_membership==1]))
    tau.a_pop[i] <- mean((Y_a_1-Y_a_0)[a_membership==1])
    tau.c_pop[i] <- mean((Y_c_1-Y_c_0)[c_membership==1])
    
  }
  
  ### True CACE, tau_a, tau_c
  tau <- mean(tau_pop)
  tau.a <- mean(tau.a_pop)
  tau.c <- mean(tau.c_pop)
  
  return(list(tau=tau, tau.a=tau.a, tau.c=tau.c))
} 
