###################################################################
# A function to calculate the metrics of interest for CACE and PCE
###################################################################

source(".../gee.smv.R")# need to change the directory here
source(".../gstandard.R")# need to change the directory here
require(geepack)
require(gee)
require(matrixcalc)
require(geesmv)

var.compare <- function(param, nsims=1000, seed=1119){

  m_bar <- param[1]
  n <- param[2]
  rho <- param[3]
  method <- param[4]
  
  #Initialize estimates of interest
  tau.gee <- rep(NA, nsims)
  
  var.naive <- rep(NA, nsims)
  var.sandwich <- rep(NA, nsims)
  var.md <- rep(NA, nsims)
  var.kc <- rep(NA, nsims)
  
  CI.naive.upper <- rep(NA, nsims)
  CI.naive.lower <- rep(NA, nsims)
  CI.sandwich.upper <- rep(NA, nsims)
  CI.sandwich.lower <- rep(NA, nsims)
  CI.md.upper <- rep(NA, nsims)
  CI.md.lower <- rep(NA, nsims)
  CI.kc.upper <- rep(NA, nsims)
  CI.kc.lower <- rep(NA, nsims) 
  
  tau.a_lower <- rep(NA, nsims)
  tau.a_upper <- rep(NA, nsims)
  tau.c_lower <- rep(NA, nsims)
  tau.c_upper <- rep(NA, nsims)

  
  for (i in 1:nsims){
    
    set.seed(seed + i)
    
    #Varying cluster sizes
    if (cv==0){
      m_vector <- rep(m_bar, n)
    } else{
      m_vector <- round(rgamma(n, shape=cv^(-2), rate=m_bar^(-1)*cv^(-2)))
      m_vector[m_vector<2] <- 2
    }
    
    cluster <- rep(1:n, m_vector)
    ind <- NULL
    for (k in 1:length(m_vector)){
      ind <- c(ind, 1:m_vector[k])
    }
    
    mu1 <- rnorm(n,0,1)
    mu2 <- rnorm(n,0,1)
    #Generate two individual covariates with cluster-specific population mean
    X1 <- rnorm(sum(m_vector), rep(mu1, m_vector), 1)
    X2 <- rnorm(sum(m_vector), rep(mu2, m_vector), 1)
    
    #Randomize cluster-level treatment
    Z <- rep(0,n)
    Z[sample(1:n, n/2)] <- 1
    Z <- rep(Z, m_vector)
    
    #Use the well-tuned mechanism parameters from the population simulation
    vector_a <- c(0, 0, 0) #for identifiability
    vector_c <- c(0.3, 0.2, 0.1)
    vector_n <- c(-0.3, 0.1, 0.2)
    
    num_a <- exp(vector_a[1]+vector_a[2]*X1+vector_a[3]*X2)
    num_c <- exp(vector_c[1]+vector_c[2]*X1+vector_c[3]*X2)
    num_n <- exp(vector_n[1]+vector_n[2]*X1+vector_n[3]*X2)
    denom <- num_a + num_c + num_n
    
    pa_vector <- num_a/denom
    pc_vector <- num_c/denom
    pn_vector <- num_n/denom
    
    membership.matrix <- NULL
    for (j in 1:sum(m_vector)){
      membership.matrix <- cbind(membership.matrix, as.vector(rmultinom(1,1,c(pa_vector[j], pc_vector[j], pn_vector[j]))))
    }
    a_membership <- membership.matrix[1,]
    c_membership <- membership.matrix[2,]
    n_membership <- membership.matrix[3,]
    
    #Cluster-level random effect
    gamma <- rep(rnorm(n, 0, sqrt(rho)), m_vector)
    
    #Generate means and the potential outcomes
    mu_a_0 <- gamma+0.3*X1+0.5*X2
    mu_a_1 <- gamma+0.6*X1+0.2*X2+3
    mu_c_0 <- gamma+0.4*X1+0.4*X2+1
    mu_c_1 <- gamma+0.8*X1+0.3*X2+3
    mu_n_0 <- mu_n_1 <- gamma+0.3*X1+0.4*X2-1
    
    #sigma2_epsilon=1-ICC
    Y_a_0 <- rnorm(sum(m_vector), mu_a_0, sqrt(1-rho))
    Y_a_1 <- rnorm(sum(m_vector), mu_a_1, sqrt(1-rho))
    Y_c_0 <- rnorm(sum(m_vector), mu_c_0, sqrt(1-rho))
    Y_c_1 <- rnorm(sum(m_vector), mu_c_1, sqrt(1-rho))
    Y_n_1 <- Y_n_0 <- rnorm(sum(m_vector), mu_n_0, sqrt(1-rho))
    
    #Generate potential diagnostic status D(1), D(0)
    D1 <- (a_membership==1)*1+(c_membership==1)*1+(n_membership==1)*0
    D0 <- (a_membership==1)*1+(c_membership==1)*0+(n_membership==1)*0
    
    #Observed D
    D=(Z==1)*D1+(Z==0)*D0
    
    #Fill up the observed outcomes using potential outcomes
    Y=rep(0, sum(m_vector))
    Y[Z==0&D==0&c_membership==1] <- Y_c_0[Z==0&D==0&c_membership==1]
    Y[Z==0&D==0&n_membership==1] <- Y_n_0[Z==0&D==0&n_membership==1]
    Y[Z==0&D==1&a_membership==1] <- Y_a_0[Z==0&D==1&a_membership==1]
    Y[Z==1&D==0&n_membership==1] <- Y_n_1[Z==1&D==0&n_membership==1]
    Y[Z==1&D==1&c_membership==1] <- Y_c_1[Z==1&D==1&c_membership==1]
    Y[Z==1&D==1&a_membership==1] <- Y_a_1[Z==1&D==1&a_membership==1]
    
    #Create simulated data set
    data <- data.frame(Y=Y, Z=Z, D=D, cluster=cluster, ind=ind)
    
    #P0=P(D=1|Z=0), always-diagnosed
    P0 <- mean(data$D[data$Z==0])
    #P1=P(D=1|Z=1), never-diagnosed
    P1 <- mean(data$D[data$Z==1])
    
    #Create interaction data useful for gee fitting
    T11 <- as.numeric(data$Z==1&data$D==1)
    T01 <- as.numeric(data$Z==0&data$D==1)
    T00 <- as.numeric(data$Z==0&data$D==0)
    T10 <- as.numeric(data$Z==1&data$D==0)
    
    model <- try(geeglm(Y~-1+T11+T01+T00+T10, id=cluster, data=data, family=gaussian, corstr=cor), silent=T)
    if (class(model)=="try-error") {next}
    
    theta <- as.numeric(coef(model)) 
    theta_11 <- theta[1]
    theta_01 <- theta[2]
    theta_00 <- theta[3]
    theta_10 <- theta[4]
    ##g^{-1}()=1
    tau.gee[i] <- theta_11 - theta_01*(P0/P1) - (theta_00-theta_10*(1-P1)/(1-P0))*(1-P0)/P1
    
    #Calculate the bounds
    ludata <- Y[Z==1&D==1]
    tau.a_lower[i] <- mean(ludata[ludata<=quantile(ludata, P0/P1)]) - theta_01
    tau.a_upper[i] <- mean(ludata[ludata>=quantile(ludata, P0/P1)]) - theta_01
    tau.c_lower[i] <- mean(ludata[ludata<=quantile(ludata, (P1-P0)/P1)]) - (theta_00-theta_10*(1-P1)/(1-P0))*(1-P0)/(P1-P0)
    tau.c_upper[i] <- mean(ludata[ludata>=quantile(ludata, (P1-P0)/P1)]) - (theta_00-theta_10*(1-P1)/(1-P0))*(1-P0)/(P1-P0)
    
    #4 types of variance estimates
    fit <- try(gee(Y~-1+T11+T01+T00+T10, id=cluster, data=data, family=gaussian, corstr=cor), silent=T)
    if (class(fit)=="try-error") {next}
    
    delta.method <- function(var.beta){
      d.beta <- c(1, -P0/P1, -(1-P0)/P1, (1-P1)/P1)
      var.tau <- t(d.beta) %*% var.beta %*% d.beta
      return(var.tau)
    }
    
    data$subject <- data$cluster
    
    if (method==1){
      var.beta.naive <- fit$naive.variance
      var.naive[i] <- delta.method(var.beta.naive)
      CI.naive.upper[i] <- tau.gee[i] + qnorm(0.975)*sqrt(var.naive[i])
      CI.naive.lower[i] <- tau.gee[i] - qnorm(0.975)*sqrt(var.naive[i])
    } else if (method==2){
      var.beta.sandwich <- fit$robust.variance
      var.sandwich[i] <- delta.method(var.beta.sandwich)
      CI.sandwich.upper[i] <- tau.gee[i] + qnorm(0.975)*sqrt(var.sandwich[i])
      CI.sandwich.lower[i] <- tau.gee[i] - qnorm(0.975)*sqrt(var.sandwich[i])
    } else if (method==3){
      fit.md <- try(GEE.var.md_new(Y~-1+T11+T01+T00+T10, id="subject", data=data, family=gaussian, corstr=cor), silent=T)
      if (class(fit.md)=="try-error") {next}
      
      var.beta.md <- fit.md$cov.beta
      var.md[i] <- delta.method(var.beta.md)
      CI.md.upper[i] <- tau.gee[i] + qnorm(0.975)*sqrt(var.md[i])
      CI.md.lower[i] <- tau.gee[i] - qnorm(0.975)*sqrt(var.md[i])
    } else if (method==4){
      fit.kc <- try(GEE.var.kc_new(Y~-1+T11+T01+T00+T10, id="subject", data=data, family=gaussian, corstr=cor), silent=T)
      if (class(fit.kc)=="try-error") {next}
      
      var.beta.kc <- fit.kc$cov.beta
      var.kc[i] <- delta.method(var.beta.kc)
      CI.kc.upper[i] <- tau.gee[i] + qnorm(0.975)*sqrt(var.kc[i])
      CI.kc.lower[i] <- tau.gee[i] - qnorm(0.975)*sqrt(var.kc[i]) 
    }
  }

  if (rho==0.01){
    tau <- gstandard(0.01)$tau
    tau.a <- gstandard(0.01)$tau.a
    tau.c <- gstandard(0.01)$tau.c
  } else if (rho==0.1){
    tau <- gstandard(0.1)$tau
    tau.a <- gstandard(0.1)$tau.a
    tau.c <- gstandard(0.1)$tau.c
  }
  
  bias <- mean(tau.gee) - tau
  MC.var <- var(tau.gee)
  rmse <- bias^2 + MC.var
  
  if (method==1){
    tau.var <- mean(var.naive, na.rm=T)
    coverage <- mean(rep(tau, nsims)<=CI.naive.upper & rep(tau, nsims)>=CI.naive.lower, na.rm=T)
  } else if (method==2){
    tau.var <- mean(var.sandwich, na.rm=T)
    coverage <- mean(rep(tau, nsims)<=CI.sandwich.upper & rep(tau, nsims)>=CI.sandwich.lower, na.rm=T) 
  } else if (method==3){
    tau.var <- mean(var.md, na.rm=T)
    coverage <- mean(rep(tau, nsims)<=CI.md.upper & rep(tau, nsims)>=CI.md.lower, na.rm=T)
  } else if (method==4){
    tau.var <- mean(var.kc, na.rm=T)
    coverage <- mean(rep(tau, nsims)<=CI.kc.upper & rep(tau, nsims)>=CI.kc.lower, na.rm=T) 
  }
  
  ### For Bounds of tau.a, tau.c
  #Average length of bounds
  tau.a_avglength <- mean(tau.a_upper - tau.a_lower)
  tau.c_avglength <- mean(tau.c_upper - tau.c_lower)
  #Coverage probabilities
  tau.a_coverage <- mean(rep(tau.a, nsims)<=tau.a_upper & rep(tau.a, nsims)>=tau.a_lower) 
  tau.c_coverage <- mean(rep(tau.c, nsims)<=tau.c_upper & rep(tau.c, nsims)>=tau.c_lower)
  #Average distance from the true value for each bound
  tau.a_upper_AD <- mean(abs(tau.a_upper-tau))
  tau.a_lower_AD <- mean(abs(tau.a_lower-tau))
  tau.c_upper_AD <- mean(abs(tau.c_upper-tau))
  tau.c_lower_AD <- mean(abs(tau.c_lower-tau))
  
  return(c(bias, MC.var, rmse, tau.var, coverage,
           tau.a_avglength, tau.c_avglength, tau.a_coverage, tau.c_coverage,
           tau.a_lower_AD, tau.a_upper_AD, tau.c_lower_AD, tau.c_upper_AD))
  
} 
