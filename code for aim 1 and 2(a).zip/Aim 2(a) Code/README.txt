The current folder includes R code for reproducing Table 2 to 11 in the PCORI progress report for "Aim 2(a)".
For questions or comments about the code please contact Fan Li at <fan.f.li@yale.edu>.

I. List of Supporting Files: These supporting files are sourced in the main files that reproduce the tables.

1) gee.smv_new.r = two modified functions from "gee.smv", about the bias-corrected estimators proposed by MD and KC;
2) gstandard.r = function to simulate the true CACE and PCE for a superpopulation, as the gold standard of comparison;
3) var.compare.r = function to calculate the metrics for comparison under scenario 1 and continuous outcome.

II. List of Main Files: These main files are used to reproduce the results in Table 1 to 6.

4) res_Table2to11.r = reproduce simulation results in Table 2 to Table 11.

III. Software 

Analyses were conducted with R, version 3.6.3 (https://www.r-project.org/).
The calculations used R packages geepack (version 1.3-1), gee (version 4.13-20), matrixcalc (version 1.0-3), geesmv (version 1.3).

IV. R commands for the installation of R packages 

install.packages(c("geepack", "gee", "matrixcalc", "geesmv")) 