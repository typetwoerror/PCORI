###################################################################################
# The following code reproduces Table 2 to 11, about scenario 1, continuous outcome
# on HPC cluster
###################################################################################

source(".../gee.smv.R")# need to change the directory here
require(geepack)
require(gee)
require(matrixcalc)
require(geesmv)

#args = commandArgs(trailingOnly = TRUE)
#cortype <- as.numeric(args[1])
#cv <- as.numeric(args[2])

#Identify the working correlation structure
if (cortype==1){
  cor <- "independence"
} else if (cortype==2){
  cor <- "exchangeable"
}

#Identify a table-format parameter constellation
m <- c(rep(50, 6*4), rep(100, 6*4))
n <- rep(c(rep(10, 2*4), rep(30, 2*4), rep(60, 2*4)), 2)
rho <- rep(c(rep(0.01, 4), rep(0.1, 4)), 6)
method <- rep(c(1, 2, 3, 4), 12)
table <- cbind(m, n, rho, method)

#Call the function to calculate the metrics for method comparison
var.result <- NULL
for (i in 1:nrow(table)){
  var.result <- rbind(var.result, var.compare(table[i, ]))
}

var.table <- data.frame(cbind(table, var.result))

#Output directory and names
mainDir = '...'
write.table(var.table, paste0(mainDir, "/table_", cortype, "_cv_", cv, ".csv"), sep =",", row.names=F)
